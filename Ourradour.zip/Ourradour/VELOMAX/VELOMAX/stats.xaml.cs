﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using MySql.Data.MySqlClient;

namespace VELOMAX
{
    /// <summary>
    /// Logique d'interaction pour stats.xaml
    /// </summary>
    public partial class stats : Window
    {
        public stats()
        {
            InitializeComponent();
        }

        public void resetcolor()
        {
            un.Foreground = Brushes.Black;
            deux.Foreground = Brushes.Black;
            trois.Foreground = Brushes.Black;
            quatre.Foreground = Brushes.Black;
            cinq.Foreground = Brushes.Black;

        }

        private void un_Checked(object sender, RoutedEventArgs e)
        {
            resetcolor();

            datagridstats.Visibility = Visibility.Visible;
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=Velomax2;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();

            command.CommandText = "select NoModele as @nm , count(*) as @de from commandes group by Nomodele ; ";
            command.Parameters.AddWithValue("@nm", "Numéro du modèle du vélo");
            command.Parameters.AddWithValue("@de", "Nombre de commande de ce vélo");
            DataTable dt = new DataTable();
            dt.Load(command.ExecuteReader());
            
            datagridstats.DataContext = dt;

                
            connection.Close();
            un.Foreground = Brushes.Red;
            un.IsChecked = true;

        }

        private void deux_Checked(object sender, RoutedEventArgs e)
        {
            resetcolor();

            datagridstats.Visibility = Visibility.Visible;
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax2;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();

            command.CommandText = "select Nom as @nm,Programmefidelo as @de from personne  order by programmefidelo   ;;";
            command.Parameters.AddWithValue("@nm", "Nom du client");
            command.Parameters.AddWithValue("@de", "Nom du programme de fidélité");
            DataTable dt = new DataTable();
            dt.Load(command.ExecuteReader());
            connection.Close();
            datagridstats.DataContext = dt;

            connection.Close();
            deux.Foreground = Brushes.Red;
            deux.IsChecked = true;


        }

        private void trois_Checked(object sender, RoutedEventArgs e)
        {
            resetcolor();
            datagridstats.Visibility = Visibility.Visible;
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax2;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();

            command.CommandText = "SELECT Nom, DATE_FORMAT(Dateinscription,@nm) as @de, DATE_FORMAT(Dateinscription,@y)+programmefide.duree as @he from Personne join programmefide on personne.programmefidelo = programmefide.description;;";
            command.Parameters.AddWithValue("@nm", " % d /% m");
            command.Parameters.AddWithValue("@de", "Jour d'éxpiration");
            command.Parameters.AddWithValue("@y", "%Y");
            command.Parameters.AddWithValue("@he", "Année d'éxpiration");
            DataTable dt = new DataTable();
            dt.Load(command.ExecuteReader());
            connection.Close();
            datagridstats.DataContext = dt;
            connection.Close();
            trois.Foreground = Brushes.Red;
            trois.IsChecked = true;


        }

        private void quatre_Checked(object sender, RoutedEventArgs e)
        {
            resetcolor();
            datagridstats.Visibility = Visibility.Visible;
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax2;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();

            command.CommandText = "select AuteurCommande as @nm,sum(total) as @de from commandes group by AuteurCommande order by sum(total) desc limit 3;";
            command.Parameters.AddWithValue("@nm", "Nom du client");
            command.Parameters.AddWithValue("@de", "Somme dépensée par le client");
            DataTable dt = new DataTable();
            dt.Load(command.ExecuteReader());
            connection.Close();
            datagridstats.DataContext = dt;
            connection.Close();
            quatre.Foreground = Brushes.Red;
            quatre.IsChecked = true;


        }

        private void cinq_Checked(object sender, RoutedEventArgs e)
        {
            resetcolor();
            datagridstats.Visibility = Visibility.Visible;
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax2;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();

            command.CommandText = "select avg(total) as @nm,avg(qte) as @de from commandes ;;";
            command.Parameters.AddWithValue("@nm", "Moyenne de prix d'une commande");
            command.Parameters.AddWithValue("@de", "Moyenne du nombre de produit dans une commande");
            DataTable dt = new DataTable();
            dt.Load(command.ExecuteReader());
            connection.Close();
            datagridstats.DataContext = dt;
            connection.Close();
            cinq.Foreground = Brushes.Red;
            cinq.IsChecked = true;

        }
    }
}
