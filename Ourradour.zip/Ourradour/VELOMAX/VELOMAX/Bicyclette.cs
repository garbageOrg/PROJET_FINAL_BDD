﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class Bicyclette : Produit
    {
        string nom;
        string grandeur;
        string ligneProduit;
        List<Fourniture> listeAssemblage = new List<Fourniture>();

        public Bicyclette()
        {

        }

        public Bicyclette(string numeroProduit, int prixUnitaire, int dateIntro, int dateDisc, string nom, string grandeur, string ligneProduit, List<Fourniture> listeAssemblage) : base(numeroProduit, prixUnitaire, dateIntro, dateDisc)
        {
            this.numeroProduit = numeroProduit;
            this.prixUnitaire = prixUnitaire;
            this.dateIntro = dateIntro;
            this.DateDisc = dateDisc;
            this.nom = nom;
            this.grandeur = grandeur;
            this.ligneProduit = ligneProduit;
            this.listeAssemblage = listeAssemblage;
        }

        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }

        public string Grandeur
        {
            get { return grandeur; }
            set { grandeur = value; }
        }

        public string LigneProduit
        {
            get { return ligneProduit; }
            set { ligneProduit = value; }
        }

        public List<Fourniture> ListeAssemblage
        {
            get { return listeAssemblage; }
            set { listeAssemblage = value; }
        }

        public override string ToString()
        {
            return base.ToString() + " " + nom + " " + grandeur + " " + ligneProduit + " " + listeAssemblage;
        }
    }
}
