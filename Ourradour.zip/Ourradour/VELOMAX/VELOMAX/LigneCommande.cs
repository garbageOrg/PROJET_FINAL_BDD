﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class LigneCommande
    {

        // Variables
        private Commande cde;
        private string numeroLigne;
        private Fourniture f;//on va chercher le produit fourni par un fournisseur en particulier
        private Bicyclette v;
        private int qteCommande;
        private int prixUnitaire;
        private int rabaisUnitaire;//peut être accessible à travers Commande -> Client -> ProgrammeFidelite

        public LigneCommande()
        {

        }

        public LigneCommande(Commande cde, string numeroLigne, Fourniture f, Bicyclette v, int qtCommande, int prixUnitaire, int rabaisUnitaire)
        {
            this.cde = cde;
            this.numeroLigne = numeroLigne;
            this.f = f;
            this.v = v;
            this.qteCommande = qteCommande;
            this.prixUnitaire = prixUnitaire;
            this.rabaisUnitaire = rabaisUnitaire;

        }

        public Commande Cde
        {
            get { return cde; }
            set { cde = value; }
        }

        public string NumeroLigne
        {
            get { return numeroLigne; }
            set { numeroLigne = value; }
        }

        public Fourniture F
        {
            get { return f; }
            set { f = value; }
        }

        public Bicyclette V
        {
            get { return v; }
            set { v = value; }
        }

        public int QtCommande
        {
            get { return qteCommande; }
            set { qteCommande = value; }
        }

        public int PrixUnitaire
        {
            get { return prixUnitaire; }
            set { prixUnitaire = value; }
        }

        public int RabaisUnitaire
        {
            get { return rabaisUnitaire; }
            set { rabaisUnitaire = value; }
        }
    }
}
