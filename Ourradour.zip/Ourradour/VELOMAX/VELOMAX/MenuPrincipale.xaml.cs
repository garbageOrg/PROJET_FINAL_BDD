﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VELOMAX
{
    /// <summary>
    /// Logique d'interaction pour MenuPrincipale.xaml
    /// </summary>
    public partial class MenuPrincipale : Window
    {
        public MenuPrincipale()
        {
            InitializeComponent();
        }

        private void GoCommande(object sender, RoutedEventArgs e)
        {
            Commandes c = new Commandes();
            c.Show();
            Close();
        }

        private void goFournisseurs(object sender, RoutedEventArgs e)
        {
            Fournisseurs f = new Fournisseurs();
            f.Show();
            Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Clients c = new Clients();
            c.Show();
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Velo v = new Velo();
            v.Show();
            Close();
        }

        private void affichestats(object sender, RoutedEventArgs e)
        {
            stats s = new stats();
            s.Show();
        }
    }
}
