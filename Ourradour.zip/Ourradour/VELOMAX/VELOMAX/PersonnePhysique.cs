﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class PersonnePhysique : Client
    {
      
        private ProgrammeFidelite fidelite;

        public PersonnePhysique()
        {

        }

        public PersonnePhysique(string nom, string prenom, string adresse,  string courriel, int telephone, ProgrammeFidelite fidelite) : base(nom,prenom, adresse, courriel, telephone)
        {
            this.nom = nom;
            this.adresse = adresse;
            this.courriel = courriel;
            this.prenom = prenom;
            this.fidelite = fidelite;

        }

        public string Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }

        public ProgrammeFidelite Fidelite
        {
            get { return fidelite; }
            set { fidelite = value; }
        }

        public override string ToString()
        {
            return prenom + " " + base.ToString();
        }
    }
}
