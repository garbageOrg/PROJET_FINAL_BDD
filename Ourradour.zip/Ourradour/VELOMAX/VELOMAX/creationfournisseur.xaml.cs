﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace VELOMAX
{
    /// <summary>
    /// Logique d'interaction pour creationfournisseur.xaml
    /// </summary>
    public partial class creationfournisseur : Window
    {
        public creationfournisseur()
        {
            InitializeComponent();
        }

        private void BouttonCliqueCreer(object sender, RoutedEventArgs e)
        {

            bool textBoxTel = Int32.TryParse(siretTextBox.Text, out int siret);
            if (textBoxTel)
            {
                var verif = MessageBox.Show($" Vous validez les informations suivantes?\nSiret: {siret}\nEntreprise: {nomentrepriseTextBox.Text}\nContact: {nomcontactTextBox.Text}\nAdresse: {adresseTextBox.Text}\nLibellé: {libelleTextBox.Text}", "Vérification", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (verif == MessageBoxResult.Yes) // Si le client clique sur Yes et est donc satisfait de son profil client
                {
                    try
                    {
                        string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                        MySqlConnection connection = new MySqlConnection(connectionString);
                        connection.Open();
                        MySqlCommand command = connection.CreateCommand();

                        command.CommandText = $" INSERT INTO fournisseur VALUES (@nm,@pm,@ae,@mx,@num)";
                        command.Parameters.AddWithValue("@nm", siret);
                        command.Parameters.AddWithValue("@pm", nomentrepriseTextBox.Text);
                        

                        command.Parameters.AddWithValue("@ae", nomcontactTextBox.Text);
                        command.Parameters.AddWithValue("@mx", adresseTextBox.Text);
                        command.Parameters.AddWithValue("@num", libelleTextBox.Text);

                        MySqlDataReader reader;
                        reader = command.ExecuteReader();
                        connection.Close();

                        Fournisseurs c = new Fournisseurs();
                        
                        c.Show();
                        Close();
                    }
                    catch (MySql.Data.MySqlClient.MySqlException)
                    {
                        MessageBox.Show("Nous vous avons déjà enregistré.");
                        Fournisseurs c = new Fournisseurs();
                        c.Show();
                        Close();
                    }

                }

            }
            else// bloque si le numéro n'est pas composé que de chiffres pour éviter des bugs
            {
                MessageBox.Show("Votre numéro de siret n'est pas exploitable.");
                siretTextBox.Text = null;
            }

        }

        private void Button_ClickRetour(object sender, RoutedEventArgs e)
        {
            Fournisseurs f = new Fournisseurs();
            f.Show();
            Close();
        }
    }
}
