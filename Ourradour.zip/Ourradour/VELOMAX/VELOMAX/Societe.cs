﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class Societe
    {
        private string nom;
        private string pdg;

        public Societe()
        {

        }

        public Societe(string nom, string pdg)
        {
            this.nom = nom;
            this.pdg = pdg;
        }

        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }

        public string Pdg
        {
            get { return pdg; }
            set { pdg = value; }
        }

        public string ToString()
        {
            return nom + " " + pdg;
        }



    }
}
