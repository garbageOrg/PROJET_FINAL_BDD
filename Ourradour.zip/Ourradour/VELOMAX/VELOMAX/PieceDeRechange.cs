﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{

    class PieceDeRechange : Produit, IComparable
    {
        private string description;
        private Fourniture fo;

        public PieceDeRechange()
        {

        }

        public PieceDeRechange(string numeroProduit, int prixUnitaire, int dateIntro, int dateDisc, string description, Fourniture fo) : base(numeroProduit, prixUnitaire, dateIntro, dateDisc)
        {
            this.numeroProduit = numeroProduit;
            this.prixUnitaire = prixUnitaire;
            this.dateIntro = dateIntro;
            this.DateDisc = dateDisc;
            this.description = description;
            this.fo = fo;

        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }



        public Fourniture Fo
        {
            get { return fo; }
            set { fo = value; }
        }

        public override string ToString()
        {
            return base.ToString() + " " + description + " " + fo.ToString();
        }

        public int CompareTo(object p2)
        {
            PieceDeRechange p1 = (PieceDeRechange)p2;
            return this.prixUnitaire.CompareTo(p1.PrixUnitaire);
        }
    }
}
