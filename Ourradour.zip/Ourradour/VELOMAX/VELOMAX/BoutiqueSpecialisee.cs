﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class BoutiqueSpecialisee : Client
    {
        string nomPersonneContact;

        public BoutiqueSpecialisee()
        {

        }

        public BoutiqueSpecialisee(string nom, string prenom,string adresse, int telephone, string courriel, string nomPersonneContact) : base(nom, prenom, adresse, courriel, telephone)
        {
            this.nom = nom;
            this.adresse = adresse;
            this.courriel = courriel;
            this.nomPersonneContact = nomPersonneContact;

        }

        public string NomPersonneContact
        {
            get { return nomPersonneContact; }
            set { nomPersonneContact = value; }
        }

        public override string ToString()
        {
            return base.ToString() + " " + nomPersonneContact;
        }
    }
}
