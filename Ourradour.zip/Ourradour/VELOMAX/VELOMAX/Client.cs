﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class Client
    {
        protected string nom;
        protected string prenom;
        protected string adresse;
        protected int telephone;
        protected string courriel;

        public Client()
        {

        }

        public Client(string nom, string prenom, string adresse, string courriel, int telephone)
        {
            this.nom = nom;
            this.prenom = prenom;
            this.adresse = adresse;
            this.telephone = telephone;
            this.courriel = courriel;
        }

        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }
        public string Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }

        public string Adresse
        {
            get { return adresse; }
            set { adresse = value; }
        }

        public int Telephone
        {
            get { return telephone; }
            set { telephone = value; }
        }

        public string Courriel
        {
            get { return courriel; }
            set { courriel = value; }
        }

        public virtual string ToString()
        {
            return nom + " " +prenom + " "+ adresse + " " + Convert.ToString( telephone) + " " + courriel;
        }
    }
}
