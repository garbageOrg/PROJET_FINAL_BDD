﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;

namespace VELOMAX
{
    /// <summary>
    /// Logique d'interaction pour Fournisseurs.xaml
    /// </summary>
    public partial class Fournisseurs : Window
    {

        public void resetcolor()
        {
            visu.Foreground = Brushes.Black;
            maj.Foreground = Brushes.Black;
            sup.Foreground = Brushes.Black;

        }

       


        public Fournisseurs()
        {
            InitializeComponent();
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = " SELECT NomEntreprise FROM fournisseur order by NomEntreprise asc ;";
            MySqlDataReader reader;
            reader = command.ExecuteReader();

            while (reader.Read())
            {
                combofournisseur.Items.Add(reader.GetString(0));
            }


            reader.Close();
            connection.Close();

            if (combofournisseur.Items == null)
            {
                MessageBox.Show("Pensez à ajouter vos fournisseurs", "CONSEIL", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            
        }

        private void retourmenu(object sender, RoutedEventArgs e)
        {
            MenuPrincipale m = new MenuPrincipale();
            m.Show();
            Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            creationfournisseur c = new creationfournisseur();
            c.Show();
            Close();
        }

        private void RadioButtonVisualiser_Checked(object sender, RoutedEventArgs e)
        {
            if (combofournisseur.SelectedItem == null)
            {
                MessageBox.Show("Selectionnez un fournisseur afin d'effectuer une action.", "Vous y êtes presque!", MessageBoxButton.OK, MessageBoxImage.Information);
                visu.IsChecked = false;

            }
            else
            {
                resetcolor();

                datagrid.Visibility = Visibility.Visible;
                string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                MySqlConnection connection = new MySqlConnection(connectionString);
                connection.Open();
                MySqlCommand command = connection.CreateCommand();

                command.CommandText = " SELECT NoSiret, NomEntreprise, contactEntreprise, adresseEntreprise, libelle FROM fournisseur where NomEntreprise =@nm ;";
                command.Parameters.AddWithValue("@nm", combofournisseur.SelectedItem.ToString());
                DataTable dt = new DataTable();
                dt.Load(command.ExecuteReader());
                connection.Close();
                datagrid.DataContext = dt;



                visu.Foreground = Brushes.Red;
                visu.IsChecked = true;


            }

    }

        private void radiobutsup(object sender, RoutedEventArgs e)
        {
            if (combofournisseur.SelectedItem == null)
            {
                MessageBox.Show("Selectionnez un fournisseur afin d'effectuer une action.", "Error", MessageBoxButton.OK);
                sup.IsChecked = false;

            }
            else
            {
                resetcolor();

                datagrid.Visibility = Visibility.Visible;
                string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                MySqlConnection connection = new MySqlConnection(connectionString);
                connection.Open();

                MySqlCommand command = connection.CreateCommand();
                command.CommandText = " SELECT NoSiret, NomEntreprise, contactEntreprise, adresseEntreprise, libelle FROM fournisseur where NomEntreprise =@nm ;";
                command.Parameters.AddWithValue("@nm", combofournisseur.SelectedItem.ToString());
                DataTable dt = new DataTable();
                dt.Load(command.ExecuteReader());


                MySqlCommand command2 = connection.CreateCommand();
                command.CommandText = " delete from fournisseur where NomEntreprise =@supnom ;";
                command.Parameters.AddWithValue("@supnom", combofournisseur.SelectedItem.ToString());
                MySqlDataReader reader;
                reader = command.ExecuteReader();
                combofournisseur.Items.RemoveAt(combofournisseur.SelectedIndex);
                combofournisseur.Text = " -- Choississez le fournisseur --";

                labelinfo.Content = "Vous venez de supprimer le fournisseur ci-dessus";

                connection.Close();

                datagrid.DataContext = dt;
                sup.Foreground = Brushes.Red;

            }



        }
      

      
        private void combofournisseur_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {   
            RadioButtonVisualiser_Checked(new object(), new RoutedEventArgs());
        }

       

        
        private void datagrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {

            if (maj.IsChecked==true)
            {

                string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                MySqlConnection connection = new MySqlConnection(connectionString);
                connection.Open();

                MySqlCommand command = connection.CreateCommand();
                command.CommandText = " SELECT NoSiret, NomEntreprise, contactEntreprise, adresseEntreprise, libelle FROM fournisseur where NomEntreprise =@nm ;";
                command.Parameters.AddWithValue("@nm", combofournisseur.SelectedItem.ToString());
                DataTable dt = new DataTable();
                dt.Load(command.ExecuteReader());

                string numsiret = dt.Rows[0].ItemArray[0].ToString();
                string cellval = ((TextBox)e.EditingElement).Text;
                int indexcolonne = e.Column.DisplayIndex;
                String nomCol = "";

                switch (indexcolonne)
                {
                    case 0:
                        MessageBox.Show("Vous ne pouvez pas changer le Numero de Siret ! ");                       
                        return;
                    case 1:
                        nomCol = "NomEntreprise";
                        MySqlCommand command1 = connection.CreateCommand();
                        command1.CommandText = "update fournisseur set NomEntreprise =@val where NoSiret = @nums; ";
                        command1.Parameters.AddWithValue("@nom", nomCol);
                        MessageBox.Show(nomCol);
                        MessageBox.Show(cellval);
                        MessageBox.Show(Convert.ToString(indexcolonne));
                        command1.Parameters.AddWithValue("@val", cellval);
                        command1.Parameters.AddWithValue("@nums", numsiret);
                        MySqlDataReader reader1;
                        reader1 = command1.ExecuteReader();
                        break;
                    case 2:
                        nomCol = "contactEntreprise";
                        MySqlCommand command2 = connection.CreateCommand();
                        command2.CommandText = "update fournisseur set contactEntreprise =@val where NoSiret = @nums; ";
                        command2.Parameters.AddWithValue("@nom", nomCol);
                        command2.Parameters.AddWithValue("@val", cellval);
                        command2.Parameters.AddWithValue("@nums", numsiret);
                        MySqlDataReader reader2;
                        reader2 = command2.ExecuteReader();
                        break;
                    case 3:
                        nomCol = "adresseEntreprise";
                        MySqlCommand command3 = connection.CreateCommand();
                        command3.CommandText = "update fournisseur set adresseEntreprise =@val where NoSiret = @nums; ";
                        command3.Parameters.AddWithValue("@nom", nomCol);
                        command3.Parameters.AddWithValue("@val", cellval);
                        command3.Parameters.AddWithValue("@nums", numsiret);
                        MySqlDataReader reader3;
                        reader3 = command3.ExecuteReader();
                        break;
                    case 4:
                        nomCol = "libelle";
                        MySqlCommand command4 = connection.CreateCommand();
                        command4.CommandText = "update fournisseur set libelle =@val where NoSiret = @nums; ";
                        command4.Parameters.AddWithValue("@nom", nomCol);
                        command4.Parameters.AddWithValue("@val", cellval);
                        command4.Parameters.AddWithValue("@nums", numsiret);
                        MySqlDataReader reader4;
                        reader4 = command4.ExecuteReader();
                        break;
                    default:
                        break;
                }

                labelinfo.Content = $"Vous avez mis à jour la rubrique {nomCol} de l'entreprise: {numsiret} ({combofournisseur.Text})";
            }
            else
            {
                MessageBox.Show("Vous devez check la mise à jour pour effectuer un changement");                
            }
           


        }

        private void majbuttoncheck(object sender, RoutedEventArgs e)
        {
            resetcolor();
            maj.Foreground = Brushes.Red;
            
        }
    }
}
