﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class Produit
    {
        
        protected string numeroProduit;
        protected int prixUnitaire; // ne sert pas car le prix d'une pièce détachée est en fonction du fournisseur
        protected int dateIntro;//année à partir de laquelle le modèle est disponible 
        protected int dateDisc;//année à partir de laquelle le modèle est obsolète (on ne peut plus commander)

        public Produit()
        {

        }

        public Produit(string numeroProduit, int prixUnitaire, int dateIntro, int dateDisc)
        {
            this.numeroProduit = numeroProduit;
            this.prixUnitaire = prixUnitaire;
            this.dateIntro = dateIntro;
            this.dateDisc = dateDisc;
        }

        public string NumeroProduit
        {
            get { return numeroProduit; }
            set { numeroProduit = value; }
        }

        public int PrixUnitaire
        {
            get { return prixUnitaire; }
            set { prixUnitaire = value; }
        }

        public int DateIntro
        {
            get { return dateIntro; }
            set { dateIntro = value; }
        }

        public int DateDisc
        {
            get { return dateDisc; }
            set { dateDisc = value; }
        }

        public virtual string ToString()
        {
            return numeroProduit + " " + prixUnitaire + " " + dateIntro + " " + dateDisc;
        }

    }
}
