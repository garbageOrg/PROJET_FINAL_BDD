﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class Fourniture  //permet de prendre en compte le fait qu'une pièce peut être fournie par plusieurs fournisseurs différents
    {
        private Produit piece;
        private Fournisseur f;
        private string numeroProduitCatalogueFournisseur;
        private int delaiLivraison;
        private int prix;

        public Fourniture()
        {

        }

        public Fourniture(Produit piece, Fournisseur f, int delaiLivraison, int prix)
        {
            this.piece = piece;
            this.f = f;
            this.delaiLivraison = delaiLivraison;
            this.prix = prix;
        }

        public Produit Piece
        {
            get { return piece; }
            set { piece = value; }
        }

        public Fournisseur F
        {
            get { return f; }
            set { f = value; }
        }

        public int DelaiLivraison
        {
            get { return delaiLivraison; }
            set { delaiLivraison = value; }
        }

        public int Prix
        {
            get { return prix; }
            set { prix = value; }
        }

        public string ToString()
        {
            return piece.NumeroProduit + " " + f.Siret + " " + delaiLivraison + " " + prix;
        }
    }
}
