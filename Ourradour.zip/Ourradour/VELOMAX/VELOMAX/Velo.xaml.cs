﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using MySql.Data.MySqlClient;

namespace VELOMAX
{
    /// <summary>
    /// Logique d'interaction pour Velo.xaml
    /// </summary>
    public partial class Velo : Window
    {
        public Velo()
        {
            InitializeComponent();
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = " SELECT distinct Nom FROM bicyclette ;";
            MySqlDataReader reader;
            reader = command.ExecuteReader();

            while (reader.Read())
            {
                combovelo.Items.Add(reader.GetString(0));
            }


            reader.Close();
            connection.Close();

        }

        public void resetimage()
        {
            un.Visibility = Visibility.Hidden;
            deux.Visibility = Visibility.Hidden;
            trois.Visibility = Visibility.Hidden;
            quatre.Visibility = Visibility.Hidden;
            cinq.Visibility = Visibility.Hidden;
            cinqbis.Visibility = Visibility.Hidden;

        }

        private void retourmenu(object sender, RoutedEventArgs e)
        {

            MenuPrincipale m = new MenuPrincipale();
            m.Show();
            Close();
        }

        private void combovelo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            resetimage();

            datagridvelo.Visibility = Visibility.Visible;
            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();

            command.CommandText = " SELECT NoModele, Grandeur, PrixUnit, LigneProduit FROM bicyclette where Nom =@nm ;";
            command.Parameters.AddWithValue("@nm", combovelo.SelectedItem.ToString());
            DataTable dt = new DataTable();
            dt.Load(command.ExecuteReader());
            connection.Close();
            datagridvelo.DataContext = dt;

            if (combovelo.SelectedItem.ToString()== "Kilimandjaro")
            {
                un.Visibility = Visibility.Visible;
            }

            if(combovelo.SelectedItem.ToString() == "NorthPole")
            {
                deux.Visibility = Visibility.Visible;
            }
            if (combovelo.SelectedItem.ToString() == "MontBlanc")
            {
                trois.Visibility = Visibility.Visible;
            }
            if (combovelo.SelectedItem.ToString() == "Hooligan")
            {
                quatre.Visibility = Visibility.Visible;
            }
            if (combovelo.SelectedItem.ToString() == "Orléans")
            {
                cinq.Visibility = Visibility.Visible;
                cinqbis.Visibility = Visibility.Visible;
            }

        }
    }
}
