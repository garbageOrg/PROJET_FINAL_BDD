﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class ProgrammeFidelite
    {
        private string noProgramme;
        private string description;
        private int coût;
        private int rabais;

        public ProgrammeFidelite()
        {

        }
        public ProgrammeFidelite(string noProgramme, string description, int coût, int rabais)
        {
            this.noProgramme = noProgramme;
            this.description = description;
            this.coût = coût;
            this.rabais = rabais;
        }

        public string NoProgramme
        {
            get { return noProgramme; }
            set { noProgramme = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public int Coût
        {
            get { return coût; }
            set { coût = value; }
        }

        public int Rabais
        {
            get { return rabais; }
            set { rabais = value; }
        }

        public string ToString()
        {
            return noProgramme + " " + description + " " + coût + " " + rabais;
        }
    }
}
