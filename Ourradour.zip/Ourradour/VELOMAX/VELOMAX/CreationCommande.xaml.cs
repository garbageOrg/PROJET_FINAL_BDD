﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using MySql.Data.MySqlClient;


namespace VELOMAX
{
    /// <summary>
    /// Logique d'interaction pour CreationCommande.xaml
    /// </summary>
    public partial class CreationCommande : Window
    {


        public CreationCommande()
        {
            InitializeComponent();
        }

        static int Nocommande()
        {

            int[] array = Enumerable.Range(0, 10).ToArray();
            var enumarator = array.GetEnumerator();
            enumarator.MoveNext();
            return (int)enumarator.Current;

        }


        private void Button_ClickRetour(object sender, RoutedEventArgs e)
        {
            Commandes c = new Commandes();
            c.Show();
            Close();
        }

        private void BouttonCreer_Click(object sender, RoutedEventArgs e)
        {
            bool textBoxnumcommande = Int32.TryParse(numerocommandeTextBox.Text, out int numerocommande);
            if (textBoxnumcommande)
            {
                var verif = MessageBox.Show($" Vous validez les informations suivantes?\nNuméro Commande: {numerocommande}\nNuméro Modèle: {numeromodeleTextBox.Text}\nQuantité: {qtTextBox.Text}\nDate Commande: {datecommandeTextBox.Text}\nAdresse Livraison: {adresselivraisonTextBox.Text}", "Vérification", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (verif == MessageBoxResult.Yes) // Si le client clique sur Yes et est donc satisfait de son profil client
                {
                    try
                    {
                        string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                        MySqlConnection connection = new MySqlConnection(connectionString);
                        connection.Open();
                        MySqlCommand command = connection.CreateCommand();

                        command.CommandText = $" INSERT INTO commandes VALUES (@nm,@pm,@ae,@mx,@num,@dtl,@rem,@tot,@aut)";
                        command.Parameters.AddWithValue("@nm", numerocommande);  //int
                        command.Parameters.AddWithValue("@pm", int.Parse(numeromodeleTextBox.Text)); //int
                        command.Parameters.AddWithValue("@ae", int.Parse(qtTextBox.Text)); //int
                        command.Parameters.AddWithValue("@mx", Convert.ToDateTime(datecommandeTextBox.Text)); //date
                        command.Parameters.AddWithValue("@num", adresselivraisonTextBox.Text); //txt
                        command.Parameters.AddWithValue("@dtl", Convert.ToDateTime(datelivraisonTextBox.Text)); //date
                        command.Parameters.AddWithValue("@rem", Convert.ToInt32(remiseTextBox.Text)); //float
                        command.Parameters.AddWithValue("@tot", Convert.ToInt32(totalTextBox.Text)); //float
                        command.Parameters.AddWithValue("@aut", auteurcommandeTextBox.Text); //txt

                        MySqlDataReader reader;
                        reader = command.ExecuteReader();
                        connection.Close();

                        Commandes co = new Commandes();

                        co.Show();
                        Close();
                    }
                    catch (MySql.Data.MySqlClient.MySqlException)
                    {
                        MessageBox.Show("Insertion impossible");
                        Commandes co = new Commandes();
                        co.Show();
                        Close();
                    }
                }
            }
        }
    } }
