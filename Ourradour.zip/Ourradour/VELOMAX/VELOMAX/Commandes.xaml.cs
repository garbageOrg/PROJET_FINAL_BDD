﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VELOMAX
{
    /// <summary>
    /// Logique d'interaction pour Commandes.xaml
    /// </summary>
    public partial class Commandes : Window
    {
        public Commandes()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            CreationCommande c = new CreationCommande();
            c.Show();
            Close();


        }

   

        private void retourmenu(object sender, RoutedEventArgs e)
        {
            MenuPrincipale m = new MenuPrincipale();
            m.Show();
            Close();

        }
    }
}
