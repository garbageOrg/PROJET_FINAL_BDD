﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class Fournisseur
    {
        private string siret;           // identifiant du fournisseur
        private string nomEntreprise;   // nom de l'entreprise fournisseur
        private string contact;         // nom prénom de la personne en contact
        private string adresse;         // adresse postale 
        private string libelle;         // notation attribuée au fournisseur


        public Fournisseur()
        {

        }


        public Fournisseur(string siret, string nomEntreprise, string contact, string adresse, string libelle)
        {
            this.siret = siret;
            this.nomEntreprise = nomEntreprise;
            this.adresse = adresse;
            this.libelle = libelle;

        }

        public string Siret
        {
            get { return this.siret; }
            set { siret = value; }
        }

        public string NomEnetrprise
        {
            get { return this.nomEntreprise; }
            set { nomEntreprise = value; }
        }

        public string Contact
        {
            get { return this.contact; }
            set { contact = value; }
        }

        public string Adresse
        {
            get { return this.adresse; }
            set { adresse = value; }
        }

        public string Libelle
        {
            get { return this.libelle; }
            set { libelle = value; }
        }


        public string ToString()
        {
            return siret + " " + nomEntreprise + " " + contact + " " + adresse + " " + libelle;
        }
    }
}
