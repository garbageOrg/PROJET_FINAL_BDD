﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using MySql.Data.MySqlClient;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VELOMAX
{
    /// <summary>
    /// Logique d'interaction pour CreationClient.xaml
    /// </summary>
    public partial class CreationClient : Window
    {
        Window windoowretour;
        public CreationClient(Window w)
        {
            windoowretour = w;
            InitializeComponent();
        }

        private void BouttonCliqueCreer(object sender, RoutedEventArgs e)
        {
            if(radioPersonne.IsChecked==true)
            {

                bool textBoxTel = Int32.TryParse(tcinq.Text, out int num);
                if (textBoxTel)
                {
                    string prog = "";
                    var boolprogramme = MessageBox.Show("Voulez vous prendre notre programme fidélo?", "OFFRE PROMOTIONNEL !", MessageBoxButton.YesNo,MessageBoxImage.Question);
                    if (boolprogramme == MessageBoxResult.Yes)
                    {
                        prog = "Oui";
                    }
                    else
                    {
                        prog = "Non";
                    }
                    try
                        {
                            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                            MySqlConnection connection = new MySqlConnection(connectionString);
                            connection.Open();
                            MySqlCommand command = connection.CreateCommand();

                            command.CommandText = $" INSERT INTO Personne VALUES (@nm,@pm,@ae,@mx,@num,@fid)";
                            command.Parameters.AddWithValue("@nm", tun.Text);
                            command.Parameters.AddWithValue("@pm", tdeux.Text);
                            command.Parameters.AddWithValue("@ae", ttrois.Text);
                            command.Parameters.AddWithValue("@mx", tquatre.Text);
                            command.Parameters.AddWithValue("@num", num);
                            command.Parameters.AddWithValue("@fid", prog);

                        MySqlDataReader reader;
                            reader = command.ExecuteReader();
                            connection.Close();

                            Window r=   this.windoowretour;
                            r.Show();
                            Close();
                        }
                    catch (MySql.Data.MySqlClient.MySqlException)
                        {
                            MessageBox.Show("Vous êtes déjà client chez nous.");
                            Window r = this.windoowretour;
                            r.Show();
                            Close();
                        }
                    
                }
                else// bloque si le numéro n'est pas composé que de chiffres pour éviter des bugs
                {
                    MessageBox.Show("Votre numéro de téléphone n'est pas exploitable.");
                    tcinq.Text = null;
                }
            }
            else
            {
                bool textBoxTel = Int32.TryParse(tcinq.Text, out int num);
                if (textBoxTel)
                {
                  
                        try
                        {
                            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                            MySqlConnection connection = new MySqlConnection(connectionString);
                            connection.Open();
                            MySqlCommand command = connection.CreateCommand();

                            command.CommandText = $" INSERT INTO boutiquespe VALUES (@nm,@pm,@ae,@mx,@num,@rem)";
                            command.Parameters.AddWithValue("@nm", tun.Text);
                            command.Parameters.AddWithValue("@pm", tdeux.Text);
                            command.Parameters.AddWithValue("@ae", ttrois.Text);
                            command.Parameters.AddWithValue("@mx", tquatre.Text);
                            command.Parameters.AddWithValue("@num", num);
                            command.Parameters.AddWithValue("@rem", 30);

                            MySqlDataReader reader;
                            reader = command.ExecuteReader();
                            connection.Close();

                            MessageBox.Show($"Nous vous avons bien rentré dans notre système informatique.\nLes achats de {tun.Text} bénéfieront de 30% de remise"," VELO MAX ",MessageBoxButton.OK,MessageBoxImage.Information);
                            
                            Window r = this.windoowretour;
                            r.Show();
                            Close();
                        }
                        catch (MySql.Data.MySqlClient.MySqlException)
                        {
                            MessageBox.Show("Vous êtes déjà client chez nous.");
                            Window r = this.windoowretour;
                            r.Show();
                            Close();
                        }
                    
                }
                else// bloque si le numéro n'est pas composé que de chiffres pour éviter des bugs
                {
                    MessageBox.Show("Votre numéro de téléphone n'est pas exploitable.");
                    tcinq.Text = null;
                }

            }
        }

        private void radioPersonne_Checked(object sender, RoutedEventArgs e)
        {
            lun.Visibility = Visibility.Visible;
            ldeux.Visibility = Visibility.Visible;
            ltrois.Visibility = Visibility.Visible;
            lquatre.Visibility = Visibility.Visible;
            lcinq.Visibility = Visibility.Visible;

            un.Visibility = Visibility.Hidden;
            deux.Visibility = Visibility.Hidden;
            trois.Visibility = Visibility.Hidden;
            quatre.Visibility = Visibility.Hidden;
            cinq.Visibility = Visibility.Hidden;

            tun.Visibility = Visibility.Visible;
            tdeux.Visibility = Visibility.Visible;
            ttrois.Visibility = Visibility.Visible;
            tquatre.Visibility = Visibility.Visible;
            tcinq.Visibility = Visibility.Visible;

            BouttonContinuer.Visibility = Visibility.Visible;
            labelidentification.Visibility = Visibility.Visible;
        }

        private void radioEntreprise_Checked(object sender, RoutedEventArgs e)
        {
            un.Visibility = Visibility.Visible;
            deux.Visibility = Visibility.Visible;
            trois.Visibility = Visibility.Visible;
            quatre.Visibility = Visibility.Visible;
            cinq.Visibility = Visibility.Visible;

            lun.Visibility = Visibility.Hidden;
            ldeux.Visibility = Visibility.Hidden;
            ltrois.Visibility = Visibility.Hidden;
            lquatre.Visibility = Visibility.Hidden;
            lcinq.Visibility = Visibility.Hidden;


            tun.Visibility = Visibility.Visible;
            tdeux.Visibility = Visibility.Visible;
            ttrois.Visibility = Visibility.Visible;
            tquatre.Visibility = Visibility.Visible;
            tcinq.Visibility = Visibility.Visible;

            BouttonContinuer.Visibility = Visibility.Visible;
            labelidentification.Visibility = Visibility.Visible;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window r = this.windoowretour;
            r.Show();
            Close();
        }
    }
}
