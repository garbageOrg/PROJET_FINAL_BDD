﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VELOMAX
{
    class Commande
    {
        //variable état du stock ?
        private string numeroCommande;
        //List<Bicyclette> veloCommande = new List<Bicyclette>();
        //List<PieceDeRechange> pieceCommande = new List<PieceDeRechange>();
        private List<LigneCommande> ligneCommande = new List<LigneCommande>(); // une ligne de commande remplace une bicyclette ou une pièce de rechange (polymorphisme)
        private DateTime dateCommande;
        //string adresseLivraison; pas besoin car on a déjà le pointeur vers le client avec son adresse
        private DateTime dateLivraison;
        private Client c;
        private string employe;

        public Commande()
        {

        }
        public Commande(string numero, List<LigneCommande> ligneCommande, DateTime dateCommande, string adresseLivraison, DateTime dateLivraison, Client c, string employe)
        {
            this.numeroCommande = numero;
            this.ligneCommande = ligneCommande;
            this.dateCommande = dateCommande;
            this.dateLivraison = dateLivraison;
            this.employe = employe;

        }

        public string NumeroCommande
        {
            get { return numeroCommande; }
            set { numeroCommande = value; }
        }


        public DateTime DateCommande
        {
            get { return dateCommande; }
            set { dateCommande = value; }
        }

        public DateTime DateLivraison
        {
            get { return dateLivraison; }
            set { dateLivraison = value; }
        }

        public Client C
        {
            get { return c; }
            set { c = value; }
        }

        public string Employe
        {
            get { return employe; }
            set { employe = value; }
        }

        public string ToString()
        {
            return numeroCommande + " " + dateCommande + " " + dateLivraison + " " + c.ToString() + " " + employe;
        }


    }
}
