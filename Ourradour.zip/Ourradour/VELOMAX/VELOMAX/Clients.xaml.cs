﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using MySql.Data.MySqlClient;

namespace VELOMAX
{
    /// <summary>
    /// Logique d'interaction pour Clients.xaml
    /// </summary>
    public partial class Clients : Window
    {
        public Clients()
        {
            InitializeComponent();



        }

   
        public void resetcolor()
        {
            visu.Foreground = Brushes.Black;
            maj.Foreground = Brushes.Black;
            sup.Foreground = Brushes.Black;

        }

        private void retourmenu(object sender, RoutedEventArgs e)
        {
            MenuPrincipale m = new MenuPrincipale();
            m.Show();
            Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CreationClient c = new CreationClient(new Clients());
            c.Show();
            Close();
        }



        private void radioPersonne_Checked_1(object sender, RoutedEventArgs e)
        {
            comboclient.Items.Clear();

            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = " SELECT Nom FROM personne order by Nom asc ;";
            MySqlDataReader reader;
            reader = command.ExecuteReader();

            while (reader.Read())
            {
                comboclient.Items.Add(reader.GetString(0));
            }


            reader.Close();
            connection.Close();

            if (comboclient.Items == null)
            {
                MessageBox.Show("Pensez à ajouter des clients ", "CONSEIL", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void radioBoutique_Checked_1(object sender, RoutedEventArgs e)
        {
            comboclient.Items.Clear();

            string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = " SELECT NomComp FROM boutiquespe order by NomComp asc ;";
            MySqlDataReader reader;
            reader = command.ExecuteReader();

            while (reader.Read())
            {
                comboclient.Items.Add(reader.GetString(0));
            }


            reader.Close();
            connection.Close();

            if (comboclient.Items == null)
            {
                MessageBox.Show("Pensez à ajouter des Boutiques", "CONSEIL", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void comboclient_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            visu_Checked(new object(), new RoutedEventArgs());
        }

        private void visu_Checked(object sender, RoutedEventArgs e)
        {


            if (comboclient.SelectedItem == null)
            {
                MessageBox.Show("Selectionnez un fournisiiiiiiiiiseur afin d'effectuer une action.", "Vous y êtes presque!", MessageBoxButton.OK, MessageBoxImage.Information);
                visu.IsChecked = false;

            }
            else
            {
                resetcolor();

                datagrid.Visibility = Visibility.Visible;
                string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                MySqlConnection connection = new MySqlConnection(connectionString);
                connection.Open();
                MySqlCommand command = connection.CreateCommand();

                if (radioBoutique.IsChecked == true)
                {
                    command.CommandText = " SELECT * from boutiquespe where NomComp =@nm ;";
                    command.Parameters.AddWithValue("@nm", comboclient.SelectedItem.ToString());

                    DataTable dt = new DataTable();
                    dt.Load(command.ExecuteReader());
                    connection.Close();
                    datagrid.DataContext = dt;
                }
                else
                {

                    command.CommandText = " SELECT * from personne where Nom =@nm ;";
                    command.Parameters.AddWithValue("@nm", comboclient.SelectedItem.ToString());

                    DataTable dt = new DataTable();
                    dt.Load(command.ExecuteReader());
                    connection.Close();
                    datagrid.DataContext = dt;
                }

                visu.Foreground = Brushes.Red;
                visu.IsChecked = true;


            }
        }

        private void sup_Checked(object sender, RoutedEventArgs e)
        {

            if (comboclient.SelectedItem == null)
            {
                MessageBox.Show("Selectionnez un fournisseur afin d'effectuer une action.", "Error", MessageBoxButton.OK);
                sup.IsChecked = null;

            }
            else
            {
                resetcolor();



                datagrid.Visibility = Visibility.Visible;
                string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                MySqlConnection connection = new MySqlConnection(connectionString);
                connection.Open();
                MySqlCommand command = connection.CreateCommand();

                if (radioBoutique.IsChecked==true)
                {

                    command.CommandText = " SELECT * from boutiquespe where NomComp =@nm ;";
                    command.Parameters.AddWithValue("@nm", comboclient.SelectedItem.ToString());

                    DataTable dt = new DataTable();
                    dt.Load(command.ExecuteReader());
                    
                    datagrid.DataContext = dt;

                    MySqlCommand command2 = connection.CreateCommand();
                    command.CommandText = " delete from boutiquespe where NomComp =@supnom ;";
                    command.Parameters.AddWithValue("@supnom", comboclient.SelectedItem.ToString());
                    MySqlDataReader reader;
                    reader = command.ExecuteReader();
                    comboclient.Items.RemoveAt(comboclient.SelectedIndex);
                    comboclient.Text = " -- Choississez le Client --";

                    labelinfo.Content = "Vous venez de supprimer la boutique ci-dessus @nm";

                }
                else
                {
                    command.CommandText = " SELECT * from personne where Nom =@nm ;";
                    command.Parameters.AddWithValue("@nm", comboclient.SelectedItem.ToString());

                    DataTable dt = new DataTable();
                    dt.Load(command.ExecuteReader());
                    
                    datagrid.DataContext = dt;

                    MySqlCommand command2 = connection.CreateCommand();
                    command.CommandText = " delete from personne where Nom =@supnom ;";
                    command.Parameters.AddWithValue("@supnom", comboclient.SelectedItem.ToString());
                    MySqlDataReader reader2;
                    reader2 = command.ExecuteReader();
                    comboclient.Items.RemoveAt(comboclient.SelectedIndex);
                    comboclient.Text = " -- Choississez le Client --";


                    labelinfo.Content = $"Vous venez de supprimer la client ci-dessus {comboclient.SelectedItem.ToString()}";


                }
                connection.Close();
                sup.Foreground = Brushes.Red;
            }
        }

        
        private void maj_Checked(object sender, RoutedEventArgs e)
        {

            resetcolor();
            maj.Foreground = Brushes.Red;
        }

        private void datagrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {


            if (maj.IsChecked == true)
            {

                if (radioBoutique.IsChecked == true)
                {

                    datagrid.Visibility = Visibility.Visible;
                    string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                    MySqlConnection connection = new MySqlConnection(connectionString);
                    connection.Open();
                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = " SELECT * from boutiquespe where NomComp =@nm ;";
                    command.Parameters.AddWithValue("@nm", comboclient.SelectedItem.ToString());
                    DataTable dt = new DataTable();
                    dt.Load(command.ExecuteReader());

                    string nom = comboclient.SelectedItem.ToString();
                    string cellval = ((TextBox)e.EditingElement).Text;
                    int indexcolonne = e.Column.DisplayIndex;
                    String nomCol = "";

                    switch (indexcolonne)
                    {

                        case 0:
                            MessageBox.Show("Vous ne pouvez pas changer le nom de la boutique ! ");
                            return;
                        case 1:
                            nomCol = "AdresseComp";
                            MySqlCommand command1 = connection.CreateCommand();
                            command1.CommandText = "update boutiquespe set AdresseComp =@val where NomComp = @nums; ";
                            command1.Parameters.AddWithValue("@nom", nomCol);
                            MessageBox.Show(nomCol);
                            MessageBox.Show(cellval);
                            MessageBox.Show(Convert.ToString(indexcolonne));
                            command1.Parameters.AddWithValue("@val", cellval);
                            command1.Parameters.AddWithValue("@nums", nom);
                            MySqlDataReader reader1;
                            reader1 = command1.ExecuteReader();
                            break;
                        case 2:
                            nomCol = "couriel";
                            MySqlCommand command2 = connection.CreateCommand();
                            command2.CommandText = "update boutiquespe set couriel =@val where NomComp = @nums; ";
                            command2.Parameters.AddWithValue("@nom", nomCol);
                            command2.Parameters.AddWithValue("@val", cellval);
                            command2.Parameters.AddWithValue("@nums", nom);
                            MySqlDataReader reader2;
                            reader2 = command2.ExecuteReader();
                            break;
                        case 3:
                            nomCol = "NomContact";
                            MySqlCommand command3 = connection.CreateCommand();
                            command3.CommandText = "update boutiquespe set NomContact =@val where NomComp = @nums; ";
                            command3.Parameters.AddWithValue("@nom", nomCol);
                            command3.Parameters.AddWithValue("@val", cellval);
                            command3.Parameters.AddWithValue("@nums", nom);
                            MySqlDataReader reader3;
                            reader3 = command3.ExecuteReader();
                            break;
                        case 4:
                            nomCol = "Telephone";
                            MySqlCommand command4 = connection.CreateCommand();
                            command4.CommandText = "update boutiquespe set Telephone =@val where NomComp = @nums; ";
                            command4.Parameters.AddWithValue("@nom", nomCol);
                            command4.Parameters.AddWithValue("@val", cellval);
                            command4.Parameters.AddWithValue("@nums", nom);
                            MySqlDataReader reader4;
                            reader4 = command4.ExecuteReader();
                            break;
                        case 5:
                            nomCol = "Remise";
                            MySqlCommand command5 = connection.CreateCommand();
                            command5.CommandText = "update boutiquespe set Remise =@val where NomComp = @nums; ";
                            command5.Parameters.AddWithValue("@nom", nomCol);
                            MessageBox.Show(nomCol);
                            MessageBox.Show(cellval);
                            MessageBox.Show(Convert.ToString(indexcolonne));
                            command5.Parameters.AddWithValue("@val", cellval);
                            command5.Parameters.AddWithValue("@nums", nom);
                            MySqlDataReader reader5;
                            reader5 = command5.ExecuteReader();
                            break;
                        default:
                            break;
                    }

                    labelinfo.Content = $"Vous avez mis à jour la rubrique {nomCol} de la boutique: {nom} ({comboclient.Text})";
                }
                else
                {

                    datagrid.Visibility = Visibility.Visible;
                    string connectionString = "SERVER=localhost;PORT=3306;DATABASE=velomax;UID=root;PASSWORD=Maoestcon33-;SSLMODE=none;";
                    MySqlConnection connection = new MySqlConnection(connectionString);
                    connection.Open();
                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = " SELECT * from personne where Nom =@nm ;";
                    command.Parameters.AddWithValue("@nm", comboclient.SelectedItem.ToString());
                    DataTable dt = new DataTable();
                    dt.Load(command.ExecuteReader());

                    string nom = comboclient.SelectedItem.ToString();
                    string cellval = ((TextBox)e.EditingElement).Text;
                    int indexcolonne = e.Column.DisplayIndex;
                    String nomCol = "";

                    switch (indexcolonne)
                    {

                        case 0:
                            MessageBox.Show("Vous ne pouvez pas changer le nom de cette personne ! ");
                            return;
                        case 1:
                            nomCol = "Prenom";
                            MySqlCommand command1 = connection.CreateCommand();
                            command1.CommandText = "update personne set Prenom =@val where Nom = @nums; ";
                            command1.Parameters.AddWithValue("@nom", nomCol);
                            MessageBox.Show(nomCol);
                            MessageBox.Show(cellval);
                            MessageBox.Show(Convert.ToString(indexcolonne));
                            command1.Parameters.AddWithValue("@val", cellval);
                            command1.Parameters.AddWithValue("@nums", nom);
                            MySqlDataReader reader1;
                            reader1 = command1.ExecuteReader();
                            break;
                        case 2:
                            nomCol = "Adresse";
                            MySqlCommand command2 = connection.CreateCommand();
                            command2.CommandText = "update personne set Adresse =@val where Nom = @nums; ";
                            command2.Parameters.AddWithValue("@nom", nomCol);
                            command2.Parameters.AddWithValue("@val", cellval);
                            command2.Parameters.AddWithValue("@nums", nom);
                            MySqlDataReader reader2;
                            reader2 = command2.ExecuteReader();
                            break;
                        case 3:
                            nomCol = "Couriel";
                            MySqlCommand command3 = connection.CreateCommand();
                            command3.CommandText = "update personne set Couriel =@val where Nom = @nums; ";
                            command3.Parameters.AddWithValue("@nom", nomCol);
                            command3.Parameters.AddWithValue("@val", cellval);
                            command3.Parameters.AddWithValue("@nums", nom);
                            MySqlDataReader reader3;
                            reader3 = command3.ExecuteReader();
                            break;
                        case 4:
                            nomCol = "NumeroTel";
                            MySqlCommand command4 = connection.CreateCommand();
                            command4.CommandText = "update personne set NumeroTel =@val where Nom = @nums; ";
                            command4.Parameters.AddWithValue("@nom", nomCol);
                            command4.Parameters.AddWithValue("@val", cellval);
                            command4.Parameters.AddWithValue("@nums", nom);
                            MySqlDataReader reader4;
                            reader4 = command4.ExecuteReader();
                            break;
                        case 5:
                            nomCol = "ProgrammeFidelo";
                            MySqlCommand command5 = connection.CreateCommand();
                            command5.CommandText = "update personne set ProgrammeFidelo =@val where Nom = @nums; ";
                            command5.Parameters.AddWithValue("@nom", nomCol);
                            MessageBox.Show(nomCol);
                            MessageBox.Show(cellval);
                            MessageBox.Show(Convert.ToString(indexcolonne));
                            command5.Parameters.AddWithValue("@val", cellval);
                            command5.Parameters.AddWithValue("@nums", nom);
                            MySqlDataReader reader5;
                            reader5 = command5.ExecuteReader();
                            break;
                        default:
                            break;
                    }

                    labelinfo.Content = $"Vous avez mis à jour la rubrique {nomCol} de la boutique: {nom} ({comboclient.Text})";

                }
            }
            else
            {
                MessageBox.Show("Vous devez check la mise à jour pour effectuer un changement");
            }
        }
    }
}
